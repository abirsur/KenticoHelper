from fastapi import FastAPI, UploadFile, Form
from pydantic import BaseModel
from typing import Dict, Any
import json
from datetime import datetime

app = FastAPI()

# JSON Data
USAGE_FACTORS = [
    {"type": "Student", "usage_pattern": "Heavy smartphone use", "depreciation_factor": 0.1},
    {"type": "Businessman", "usage_pattern": "Frequent laptop use", "depreciation_factor": 0.03},
    {"type": "Digital Creator", "usage_pattern": "Extensive gadget use", "depreciation_factor": 0.08},
    {"type": "Engineer", "usage_pattern": "Mixed device usage", "depreciation_factor": 0.06},
    {"type": "Freelancer", "usage_pattern": "Frequent smartphone and laptop use", "depreciation_factor": 0.09}
]

WEATHER_IMPACT_FACTORS = [
    {"region": "Tropical", "humidity": 85, "temperature": 32, "impact_score": 0.8},
    {"region": "Arctic", "humidity": 20, "temperature": -10, "impact_score": 0.5},
    {"region": "Coastal", "humidity": 75, "temperature": 28, "impact_score": 0.7},
    {"region": "Dry", "humidity": 10, "temperature": 40, "impact_score": 0.4},
    {"region": "Mountain", "humidity": 50, "temperature": 10, "impact_score": 0.65}
]


# Utility Functions
def get_usage_depreciation_factor(occupation: str) -> float:
    for factor in USAGE_FACTORS:
        if factor["type"] == occupation:
            return factor["depreciation_factor"]
    return 0  # Default if occupation is not found


def get_weather_impact(region: str) -> float:
    for weather in WEATHER_IMPACT_FACTORS:
        if weather["region"] == region:
            return weather["impact_score"]
    return 0  # Default if region is not found


def get_condition_score(video: UploadFile) -> float:
    # Simulate condition score retrieval from video (replace with API call logic)
    return 0.7  # Default score for demonstration


def get_weather_details(location: str) -> str:
    # Simulate weather details retrieval (replace with API call logic)
    return "Tropical"  # Default region for demonstration


def calculate_depreciation_factor(condition_score: float, years_owned: int) -> float:
    condition_adjustment = 0.05 if condition_score < 5 else 0
    return (0.10 * years_owned) + condition_adjustment


CATEGORY_PREMIUM_RATES = {
    "Smartphones": 50.0,
    "Laptops": 100.0,
    "Tablets": 70.0,
    "Wearables": 40.0,
    "Appliances": 150.0,
    "Gaming": 90.0,
    "Home Audio": 60.0,
    "Smart TVs": 120.0,
    "Smart Home Devices": 80.0,
    "Headphones": 30.0,
}

def calculate_base_premium(category: str, purchase_price: float) -> float:  
    # Get the premium rate for the category, default to 0 if not found
    base_rate = CATEGORY_PREMIUM_RATES.get(category, 0.0)
    if base_rate == 0.0:
        raise ValueError(f"Category '{category}' is not supported.")
    
    # Calculate base premium as a percentage of the purchase price
    base_premium = base_rate + (0.05 * purchase_price)  # 5% of the purchase price
    return round(base_premium, 2)

# Request Model
class InsuranceRequest(BaseModel):
    product_info: Dict[str, Any]
    customer_location: str
    customer_occupation: str
    purchase_date: str
    purchase_price: float
    no_of_past_claims: int


# Route
@app.post("/calculate-insurance")
async def calculate_insurance(
    product_info: InsuranceRequest,
    product_condition_video: UploadFile,
):
    data = product_info.dict()

    # Extract condition score from video
    condition_score = get_condition_score(product_condition_video)

    # Get weather details
    weather_condition = get_weather_details(data["customer_location"])
    weather_impact = get_weather_impact(weather_condition)

    # Get usage depreciation factor
    usage_depreciation = get_usage_depreciation_factor(data["customer_occupation"])

    # Calculate combined depreciation
    combined_depreciation = (usage_depreciation + weather_impact) / 2  # Averaging factors

    # Calculate depreciation factor
    years_owned = max(0, datetime.now().year - int(data["purchase_date"].split("-")[0]))
    depreciation_factor = calculate_depreciation_factor(condition_score, years_owned)

    # Calculate IDV and adjusted premium
    purchase_price = data["purchase_price"]
    idv = purchase_price * (1 - depreciation_factor)
    base_premium = calculate_base_premium(data["category"], purchase_price)  # Assume a base premium
    adjusted_premium = base_premium * (1 + combined_depreciation)

    # Calculate coverages
    basic_coverage = adjusted_premium + (0.10 * adjusted_premium)
    standard_coverage = adjusted_premium + (0.20 * adjusted_premium)
    comprehensive_coverage = adjusted_premium + (0.30 * adjusted_premium)

    return {
        "DepreciationFactor": depreciation_factor,
        "ConditionScore": condition_score,
        "WeatherImpact": weather_impact,
        "UsageDepreciation": usage_depreciation,
        "IDV": idv,
        "AdjustedPremium": adjusted_premium,
        "BasicCoverage": basic_coverage,
        "StandardCoverage": standard_coverage,
        "ComprehensiveCoverage": comprehensive_coverage,
    }
