from typing import Optional
from pydantic import BaseModel
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain.llms import OpenAI


# Define Pydantic model for the API response
class DepreciationResponse(BaseModel):
    DepreciationFactor: Optional[float]


# API integration logic
def fetch_depreciation_factor_with_langchain(
    product_name: str,
    product_model: str,
    category: str,
    sub_category: str,
    user_type: str,
    weather_conditions: str,
    condition_adjustment: float,
    usage_depreciation: float,
    weather_impact: float,
    hardware_depreciation: float,
    years_owned: int,
) -> Optional[float]:
    # Define the prompt
    prompt = f"""
    Calculate the DepreciationFactor based on the following details:
    
    Parameters:
    - Product Name: {product_name}
    - Product Model: {product_model}
    - Category: {category}
    - Sub-Category: {sub_category}
    - User Type: {user_type}
    - Weather Conditions: {weather_conditions}
    - Usage Depreciation: {usage_depreciation}
    - Weather Impact: {weather_impact}
    - Hardware Depreciation: {hardware_depreciation}
    - Condition Adjustment: {condition_adjustment}
    - Years Owned: {years_owned}
    """

    # Use LangChain LLM to call the API
    llm = OpenAI(model_name="gpt-4")  # Replace with your configured LLM
    chain = LLMChain(prompt=PromptTemplate(input_variables=["input"], template="{input}"), llm=llm)
    response = chain.run({"input": prompt})

    # Parse the response with Pydantic
    try:
        parsed_response = DepreciationResponse.parse_raw(response)
        return parsed_response.DepreciationFactor
    except Exception as e:
        print(f"Failed to parse API response: {e}")
        return None


# Depreciation factor calculation
def calculate_depreciation_factor(
    product_name: str,
    product_model: str,
    category: str,
    sub_category: str,
    user_type: str,
    weather_conditions: str,
    usage_depreciation: float,
    weather_impact: float,
    hardware_depreciation: float,
    condition_adjustment: float,
    years_owned: int,
) -> float:
    # Try to fetch the depreciation factor from the API
    depreciation_factor = fetch_depreciation_factor_with_langchain(
        product_name=product_name,
        product_model=product_model,
        category=category,
        sub_category=sub_category,
        user_type=user_type,
        weather_conditions=weather_conditions,
        usage_depreciation=usage_depreciation,
        weather_impact=weather_impact,
        hardware_depreciation=hardware_depreciation,
        condition_adjustment=condition_adjustment,
        years_owned=years_owned,
    )

    # If API response is valid, use it; otherwise, calculate locally
    if depreciation_factor is not None:
        return depreciation_factor
    else:
        # Fallback logic for local calculation
        return (
            (usage_depreciation * years_owned)
            + condition_adjustment
            + weather_impact
            + hardware_depreciation
        )
