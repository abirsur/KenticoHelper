from neo4j import GraphDatabase
from datasets import Dataset, Features, Value
import json

class DepreciationDatasetGenerator:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))
    
    def close(self):
        self.driver.close()

    
    
    def fetch_data_and_generate_dataset(self, query, output_file_path):
        system_prompts =[]
        user_prompts = []
        assistant_response = []
        with self.driver.session() as session:
            results = session.run(query)
            # Fetch all records into a list to prevent consuming the result
            records = list(results)           
            
            for record in records:
                ProductName =  record.get("ProductName") 
                ProductModel =  record.get("ProductModel") 
                Category =  record.get("Category") 
                SubCategory =  record.get("SubCategory") 
                UserTypes =  record.get("UserTypes") 
                WeatherConditions = record.get("WeatherConditions")
                UsageDepreciation =  record.get("UsageDepreciation") 
                WeatherImpact =  record.get("WeatherImpact") 
                HardwareDepreciation =  record.get("HardwareDepreciation") 
                ConditionScore = record.get("ConditionScore")
                YearsOwned = record.get("YearsOwned")
                BasePremium = record.get("BasePremium")
                PurchasePrice = record.get("PurchasePrice")
                DepreciationFactor = record.get("DepreciationFactor")
                IDV =  record.get("IDV") 
                AdjustedPremium =  record.get("AdjustedPremium") 
                BasicCoverage =  record.get("BasicCoverage") 
                StandardCoverage =  record.get("StandardCoverage") 
                ComprehensiveCoverage =record.get("ComprehensiveCoverage")
                ConditionAdjustment =record.get("ConditionAdjustment")
                system_prompts.append("You are an insurance assistant that calculates premiums and coverage plans for electronic gadgets based on user inputs.")
                user_prompts.append(rf"Calculate the IDV, DepreciationFactor, AdjustedPremium, BasicCoverage, StandardCoverage and ComprehensiveCoverage based on the following details:\n\nParameters:\n- Product Name: {ProductName}\n- Product Model: {ProductModel}\n- Category: {Category}\n- Sub-Category: {SubCategory}\n- User Type: {UserTypes}\n- Weather Conditions: {WeatherConditions}\n- Condition Score: {ConditionScore}\n- ConditionAdjustment: {ConditionAdjustment}\n- Years Owned: {YearsOwned}\n- Base Premium: ${BasePremium}\n- Purchase Price: ${PurchasePrice}\n\n ")
                assistant_response.append(rf"IDV: {IDV}, DepreciationFactor: {DepreciationFactor}, AdjustedPremium: {AdjustedPremium}, BasicCoverage: {BasicCoverage}, StandardCoverage: {StandardCoverage}, ComprehensiveCoverage: {ComprehensiveCoverage} ")
        features = Features({
            "system_prompt": Value("string"),
            "user_prompt": Value("string"),
            "assistant_response": Value("string")
        })

        data = {
            "system_prompt": system_prompts,
            "user_prompt": user_prompts,
            "assistant_response": assistant_response
        }

        dataset = Dataset.from_dict(data, features=features)
        dataset[0]
        dataset.save_to_disk(output_file_path)        
            
        

# Define your query
query = """

MATCH (cat:MasterCategory)-[:HAS_SUB_CATEGORY]->(sub:SubCategory)-[:HAS_PRODUCT]->(p:Product)
OPTIONAL MATCH (p)-[:USE_BY]->(u:UserType)
OPTIONAL MATCH (p)-[:WEATHER_IMPACT]->(w:WeatherCondition)
OPTIONAL MATCH (p)-[:HAS_COMPONENT]->(c:Component)
OPTIONAL MATCH (p)-[:HAS_PREMIUM]->(bp:BasePremium)
OPTIONAL MATCH (p)-[:HAS_YEARS_SINCE_PURCHASE]->(ysp:YearsSincePurchase)
OPTIONAL MATCH (p)-[:HAS_CONDITION]->(ic:ItemCondition)
WITH 
    p, 
    cat.name AS Category, 
    sub.name AS SubCategory, 
    u.type AS UserTypes, 
    w.region AS WeatherConditions,
    COALESCE(toFloat(bp.amount)) AS BasePremium,
    COALESCE(toInteger(ysp.years)) AS YearsOwned,
    COALESCE(toInteger(ic.condition)) AS ConditionScore,
    COALESCE(AVG(u.depreciation_factor), 0) AS UsageDepreciation,
    COALESCE(AVG(toFloat(w.impact_score)/10), 0) AS WeatherImpact,
    COALESCE(AVG(toFloat(c.degradation_rate)), 0) AS HardwareDepreciation,
    COALESCE(AVG(toFloat(ic.condition)/100), 0) AS ConditionAdjustment,
    COALESCE(toFloat(p.mrp), 0) AS PurchasePrice
WITH 
    p, 
    Category, 
    SubCategory, 
    UserTypes, 
    WeatherConditions, 
    BasePremium,
    YearsOwned,
    ConditionScore,
    UsageDepreciation,
    WeatherImpact,
    HardwareDepreciation,
    ConditionAdjustment,
    PurchasePrice,    
    (COALESCE(toFloat(UsageDepreciation), 0) * COALESCE(YearsOwned, 0)) + COALESCE(toFloat(ConditionAdjustment), 0)  + COALESCE(toFloat(WeatherImpact), 0) + COALESCE(toFloat(HardwareDepreciation), 0) AS DepreciationFactor,
    COALESCE(PurchasePrice, 0) * (1 - ((COALESCE(toFloat(UsageDepreciation), 0) * COALESCE(YearsOwned, 0)) + COALESCE(toFloat(ConditionAdjustment), 0)  + COALESCE(toFloat(WeatherImpact), 0) + COALESCE(toFloat(HardwareDepreciation), 0))) AS IDV,
    COALESCE(BasePremium, 0) * (1 + ((COALESCE(toFloat(UsageDepreciation), 0) * COALESCE(YearsOwned, 0)) + COALESCE(toFloat(ConditionAdjustment), 0)  + COALESCE(toFloat(WeatherImpact), 0) + COALESCE(toFloat(HardwareDepreciation), 0))) AS AdjustedPremium
WITH 
    p.name AS ProductName, 
    p.model AS ProductModel, 
    Category, 
    SubCategory, 
    UserTypes, 
    WeatherConditions, 
    BasePremium,
    YearsOwned,
    ConditionScore,
    UsageDepreciation, 
    WeatherImpact, 
    HardwareDepreciation,
	ConditionAdjustment,
	PurchasePrice,
    DepreciationFactor,
    IDV,
    AdjustedPremium,
    AdjustedPremium + (0.10 * COALESCE(AdjustedPremium, 0)) AS BasicCoverage,
    AdjustedPremium + (0.20 * COALESCE(AdjustedPremium, 0)) AS StandardCoverage,
    AdjustedPremium + (0.30 * COALESCE(AdjustedPremium, 0)) AS ComprehensiveCoverage
RETURN 
    ProductName, 
    ProductModel, 
    Category, 
    SubCategory, 
    UserTypes, 
    WeatherConditions,
    UsageDepreciation, 
    WeatherImpact, 
    HardwareDepreciation, 
    ConditionScore,
    YearsOwned,
    BasePremium,
	PurchasePrice,
	ConditionAdjustment,
    DepreciationFactor,
    IDV, 
    AdjustedPremium, 
    BasicCoverage, 
    StandardCoverage, 
    ComprehensiveCoverage
ORDER BY Category, SubCategory, ProductName;
"""

# Initialize and run
generator = DepreciationDatasetGenerator(uri="bolt://localhost:7691", user="admin", password="admin1234")
generator.fetch_data_and_generate_dataset(query, "data_ds")
generator.close()
