from neo4j import GraphDatabase
import json

class DepreciationDatasetGenerator:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))
    
    def close(self):
        self.driver.close()
    
    def fetch_data_and_generate_dataset(self, query, output_file):
        with self.driver.session() as session:
            results = session.run(query)
            # Fetch all records into a list to prevent consuming the result
            records = list(results)
            
            data = []
            for record in records:
                ProductName =  record.get("ProductName") 
                ProductModel =  record.get("ProductModel") 
                Category =  record.get("Category") 
                SubCategory =  record.get("SubCategory") 
                UserTypes =  record.get("UserTypes") 
                WeatherConditions = record.get("WeatherConditions")
                UsageDepreciation =  record.get("UsageDepreciation") 
                WeatherImpact =  record.get("WeatherImpact") 
                HardwareDepreciation =  record.get("HardwareDepreciation") 
                ConditionScore = record.get("ConditionScore")
                YearsOwned = record.get("YearsOwned")
                BasePremium = record.get("BasePremium")
                PurchasePrice = record.get("PurchasePrice")
                DepreciationFactor = record.get("DepreciationFactor")
                IDV =  record.get("IDV") 
                AdjustedPremium =  record.get("AdjustedPremium") 
                BasicCoverage =  record.get("BasicCoverage") 
                StandardCoverage =  record.get("StandardCoverage") 
                ComprehensiveCoverage =record.get("ComprehensiveCoverage")
                ConditionAdjustment =record.get("ConditionAdjustment")

                # Generate JSONL format
                jsonl_entry = [
                                    {
                                        "role": "system",
                                        "content": "You are an insurance assistant that calculates premiums and coverage plans for electronic gadgets based on user inputs. Provide step-by-step explanations for clarity and ensure all calculations are accurate."
                                    },
                                    {
                                        "role": "user",
                                        "content": rf"Calculate the IDV, DepreciationFactor, AdjustedPremium, BasicCoverage, StandardCoverage and ComprehensiveCoverage based on the following details:\n\nParameters:\n- Product Name: {ProductName}\n- Product Model: {ProductModel}\n- Category: {Category}\n- Sub-Category: {SubCategory}\n- User Type: {UserTypes}\n- Weather Conditions: {WeatherConditions}\n- Condition Score: {ConditionScore}\n- ConditionAdjustment: {ConditionAdjustment}\n- Years Owned: {YearsOwned}\n- Base Premium: ${BasePremium}\n- Purchase Price: ${PurchasePrice}\n\n "
                                    },
                                    {
                                        "role": "assistant",
                                        "content": rf"IDV: {IDV}, DepreciationFactor: {DepreciationFactor}, AdjustedPremium: {AdjustedPremium}, BasicCoverage: {BasicCoverage}, StandardCoverage: {StandardCoverage}, ComprehensiveCoverage: {ComprehensiveCoverage} "
                                    }
                        ]

                data.append(jsonl_entry)
            
            # Write to JSONL file
            with open(output_file, "w") as f:
                for entry in data:
                    f.write(json.dumps(entry) + "\n")
            print(f"Dataset written to {output_file}")

# Define your query
query = """

MATCH (cat:MasterCategory)-[:HAS_SUB_CATEGORY]->(sub:SubCategory)-[:HAS_PRODUCT]->(p:Product)
OPTIONAL MATCH (p)-[:USE_BY]->(u:UserType)
OPTIONAL MATCH (p)-[:WEATHER_IMPACT]->(w:WeatherCondition)
OPTIONAL MATCH (p)-[:HAS_COMPONENT]->(c:Component)
OPTIONAL MATCH (p)-[:HAS_PREMIUM]->(bp:BasePremium)
OPTIONAL MATCH (p)-[:HAS_YEARS_SINCE_PURCHASE]->(ysp:YearsSincePurchase)
OPTIONAL MATCH (p)-[:HAS_CONDITION]->(ic:ItemCondition)
WITH 
    p, 
    cat.name AS Category, 
    sub.name AS SubCategory, 
    u.type AS UserTypes, 
    w.region AS WeatherConditions,
    COALESCE(toFloat(bp.amount)) AS BasePremium,
    COALESCE(toInteger(ysp.years)) AS YearsOwned,
    COALESCE(toInteger(ic.condition)) AS ConditionScore,
    COALESCE(AVG(u.depreciation_factor), 0) AS UsageDepreciation,
    COALESCE(AVG(toFloat(w.impact_score)/10), 0) AS WeatherImpact,
    COALESCE(AVG(toFloat(c.degradation_rate)), 0) AS HardwareDepreciation,
    COALESCE(AVG(toFloat(ic.condition)/100), 0) AS ConditionAdjustment,
    COALESCE(toFloat(p.mrp), 0) AS PurchasePrice
WITH 
    p, 
    Category, 
    SubCategory, 
    UserTypes, 
    WeatherConditions, 
    BasePremium,
    YearsOwned,
    ConditionScore,
    UsageDepreciation,
    WeatherImpact,
    HardwareDepreciation,
    ConditionAdjustment,
    PurchasePrice,    
    (COALESCE(toFloat(UsageDepreciation), 0) * COALESCE(YearsOwned, 0)) + COALESCE(toFloat(ConditionAdjustment), 0)  + COALESCE(toFloat(WeatherImpact), 0) + COALESCE(toFloat(HardwareDepreciation), 0) AS DepreciationFactor,
    COALESCE(PurchasePrice, 0) * (1 - ((COALESCE(toFloat(UsageDepreciation), 0) * COALESCE(YearsOwned, 0)) + COALESCE(toFloat(ConditionAdjustment), 0)  + COALESCE(toFloat(WeatherImpact), 0) + COALESCE(toFloat(HardwareDepreciation), 0))) AS IDV,
    COALESCE(BasePremium, 0) * (1 + ((COALESCE(toFloat(UsageDepreciation), 0) * COALESCE(YearsOwned, 0)) + COALESCE(toFloat(ConditionAdjustment), 0)  + COALESCE(toFloat(WeatherImpact), 0) + COALESCE(toFloat(HardwareDepreciation), 0))) AS AdjustedPremium
WITH 
    p.name AS ProductName, 
    p.model AS ProductModel, 
    Category, 
    SubCategory, 
    UserTypes, 
    WeatherConditions, 
    BasePremium,
    YearsOwned,
    ConditionScore,
    UsageDepreciation, 
    WeatherImpact, 
    HardwareDepreciation,
	ConditionAdjustment,
	PurchasePrice,
    DepreciationFactor,
    IDV,
    AdjustedPremium,
    AdjustedPremium + (0.10 * COALESCE(AdjustedPremium, 0)) AS BasicCoverage,
    AdjustedPremium + (0.20 * COALESCE(AdjustedPremium, 0)) AS StandardCoverage,
    AdjustedPremium + (0.30 * COALESCE(AdjustedPremium, 0)) AS ComprehensiveCoverage
RETURN 
    ProductName, 
    ProductModel, 
    Category, 
    SubCategory, 
    UserTypes, 
    WeatherConditions,
    UsageDepreciation, 
    WeatherImpact, 
    HardwareDepreciation, 
    ConditionScore,
    YearsOwned,
    BasePremium,
	PurchasePrice,
	ConditionAdjustment,
    DepreciationFactor,
    IDV, 
    AdjustedPremium, 
    BasicCoverage, 
    StandardCoverage, 
    ComprehensiveCoverage
ORDER BY Category, SubCategory, ProductName;
"""

# Initialize and run
generator = DepreciationDatasetGenerator(uri="bolt://localhost:7691", user="admin", password="admin1234")
generator.fetch_data_and_generate_dataset(query, "train_dataset.jsonl")
generator.close()
