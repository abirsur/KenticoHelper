from neo4j import GraphDatabase
import csv

class Neo4jDataLoader:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def close(self):
        self.driver.close()

    def _execute_query(self, query, parameters=None):
        with self.driver.session() as session:
            return session.run(query, parameters)

    def load_master_category(self, csv_file_path):
        with open(csv_file_path, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                self._execute_query(
                    """
                    MERGE (mc:MasterCategory {name: $name})
                    """, 
                    parameters={"name": row["name"]}
                )

    def load_subcategories(self, csv_file_path):
        with open(csv_file_path, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                self._execute_query(
                    """
                    MATCH (mc:MasterCategory {name: "Electronic Gadgets"})
                    MERGE (sc:SubCategory {name: $name})
                    MERGE (mc)-[:HAS_SUB_CATEGORY]->(sc)
                    """, 
                    parameters={"name": row["name"]}
                )

    def load_products(self, csv_file_path):
        with open(csv_file_path, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                self._execute_query(
                    """
                    MATCH (sc:SubCategory {name: $subcategory_id})
                    MERGE (p:Product {product_id:$product_id, name: $name, model: $model, year_of_release: toInteger($year_of_release), mrp: toFloat($mrp)})
                    MERGE (sc)-[:HAS_PRODUCT]->(p)
                    """, 
                    parameters={
                        "product_id": row["product_id"],
                        "subcategory_id": row["subcategory_id"],
                        "name": row["name"],
                        "model": row["model"],
                        "year_of_release": row["year_of_release"],
                        "mrp": row["mrp"]
                    }
                )

    def load_product_components(self, csv_file_path):
        with open(csv_file_path, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                self._execute_query(
                    """
                    MATCH (p:Product {model: $product_id})
                    MERGE (c:Component {type: $type, name: $name})
                    SET c.quality_score = toFloat($quality_score),
                        c.degradation_rate = toFloat($degradation_rate),
                        c.stability_score = toFloat($stability_score)
                    MERGE (p)-[:HAS_COMPONENT]->(c)
                    """, 
                    parameters={
                        "product_id": row["product_id"],
                        "type": row["type"],
                        "name": row["name"],
                        "quality_score": row["quality_score"],
                        "degradation_rate": row["degradation_rate"],
                        "stability_score": row["stability_score"]
                    }
                )

    def load_base_premium(self, csv_file_path):
        with open(csv_file_path, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                self._execute_query(
                    """
                    MERGE (bp:BasePremium {amount: toFloat($amount)})
                    """, 
                    parameters={"amount": row["amount"]}
                )

    def load_years_since_purchase(self, csv_file_path):
        with open(csv_file_path, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                self._execute_query(
                    """
                    MERGE (ysp:YearsSincePurchase {years: toInteger($years)})
                    """, 
                    parameters={"years": row["years"]}
                )

    def load_item_conditions(self, csv_file_path):
        with open(csv_file_path, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                self._execute_query(
                    """
                    MERGE (ic:ItemCondition {condition: toInteger($condition)})
                    """, 
                    parameters={"condition": row["condition"]}
                )

    def create_relationships_with_additional_data(self, products_csv, base_premium_csv, years_csv, conditions_csv):
        products = self._load_data_from_csv(products_csv)
        base_premiums = self._load_data_from_csv(base_premium_csv)
        years_since_purchase = self._load_data_from_csv(years_csv)
        item_conditions = self._load_data_from_csv(conditions_csv)

        for product in products:
            product_id = product['product_id']

            # Link product to base premiums (HAS_PREMIUM)
            for bp in base_premiums:
                amount = bp['amount']
                self._execute_query(
                    """
                    MATCH (p:Product {product_id: $product_id})
                    MATCH (bp:BasePremium {amount: toFloat($amount)})
                    MERGE (p)-[:HAS_PREMIUM]->(bp)
                    """, 
                    parameters={"product_id": product_id, "amount": amount}
                )

            # Link product to years since purchase (HAS_YEARS_SINCE_PURCHASE)
            for ysp in years_since_purchase:
                years = ysp['years']
                self._execute_query(
                    """
                    MATCH (p:Product {product_id: $product_id})
                    MATCH (ysp:YearsSincePurchase {years: toInteger($years)})
                    MERGE (p)-[:HAS_YEARS_SINCE_PURCHASE]->(ysp)
                    """, 
                    parameters={"product_id": product_id, "years": years}
                )

            # Link product to item conditions (HAS_CONDITION)
            for ic in item_conditions:
                condition = ic['condition']
                self._execute_query(
                    """
                    MATCH (p:Product {product_id: $product_id})
                    MATCH (ic:ItemCondition {condition: toInteger($condition)})
                    MERGE (p)-[:HAS_CONDITION]->(ic)
                    """, 
                    parameters={"product_id": product_id, "condition": condition}
                )

    
    def load_product_components(self, csv_file_path):
        """Load components (hardware, battery, software) for each product"""
        with open(csv_file_path, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                self._execute_query(
                    """
                    MATCH (p:Product {model: $product_id})
                    MERGE (c:Component {type: $type, name: $name})
                    SET c.quality_score = toFloat($quality_score),
                        c.degradation_rate = toFloat($degradation_rate),
                        c.stability_score = toFloat($stability_score)
                    MERGE (p)-[:HAS_COMPONENT]->(c)
                    """, 
                    parameters={
                        "product_id": row["product_id"],
                        "type": row["type"],
                        "name": row["name"],
                        "quality_score": row["quality_score"],
                        "degradation_rate": row["degradation_rate"],
                        "stability_score": row["stability_score"]
                    }
                )

    def load_user_types(self, csv_file_path):
        """Load user types with associated depreciation factors and usage patterns"""
        with open(csv_file_path, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                self._execute_query(
                    """
                    MERGE (u:UserType {type: $type})
                    SET u.usage_pattern = $usage_pattern,
                        u.depreciation_factor = toFloat($depreciation_factor)
                    """, 
                    parameters={
                        "type": row["type"],
                        "usage_pattern": row["usage_pattern"],
                        "depreciation_factor": row["depreciation_factor"]
                    }
                )

    def load_weather_conditions(self, csv_file_path):
        """Load weather conditions with their properties"""
        with open(csv_file_path, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                self._execute_query(
                    """
                    MERGE (w:WeatherCondition {region: $region})
                    SET w.humidity = toFloat($humidity),
                        w.temperature = toFloat($temperature),
                        w.impact_score = toFloat($impact_score)
                    """, 
                    parameters={
                        "region": row["region"],
                        "humidity": row["humidity"],
                        "temperature": row["temperature"],
                        "impact_score": row["impact_score"]
                    }
                )

    def _load_product_components_for_product(self, product_id):
        """Load components for a specific product and create HAS_COMPONENT relationships."""
        components_csv = 'product_components.csv'  # Path to your CSV file
        
        # Load product components for the given product_id
        components = self._load_data_from_csv(components_csv)
        
        # Filter components for the given product_id
        product_components = [c for c in components if c['product_id'] == product_id]
        
        if not product_components:
            print(f"No components found for product {product_id}")
            return
        
        # Create relationships between the product and its components
        for component in product_components:
            component_name = component['name']
            component_type = component['type']
            quality_score = component['quality_score']
            degradation_rate = component['degradation_rate']
            stability_score = component['stability_score']
            
            print(f"Creating HAS_COMPONENT relationship: Product {product_id} -> Component {component_name}")
            
            # Create the HAS_COMPONENT relationship
            self._execute_query(
                """
                MATCH (p:Product {product_id: $product_id})
                MERGE (c:Component {name: $component_name, type: $component_type})
                MERGE (p)-[:HAS_COMPONENT]->(c)
                SET c.quality_score = $quality_score,
                    c.degradation_rate = $degradation_rate,
                    c.stability_score = $stability_score
                """,
                parameters={
                    "product_id": product_id,
                    "component_name": component_name,
                    "component_type": component_type,
                    "quality_score": quality_score,
                    "degradation_rate": degradation_rate,
                    "stability_score": stability_score
                }
            )


    def create_relationships(self, products_csv, user_types_csv, weather_conditions_csv):
        """Create relationships between products, user types, and weather conditions"""

        # Load products, user types, and weather conditions from their respective CSVs
        products = self._load_data_from_csv(products_csv)
        user_types = self._load_data_from_csv(user_types_csv)
        weather_conditions = self._load_data_from_csv(weather_conditions_csv)

        # Create relationships between products, user types, and weather conditions
        for product in products:
            product_id = product['product_id']
            print(f"Processing product: {product_id}")

            # Link product to user types (USE_BY)
            for user_type in user_types:
                user_type_name = user_type['type']
                print(f"Creating USE_BY relationship: Product {product_id} -> User Type {user_type_name}")
                self._execute_query(
                    """
                    MATCH (p:Product {product_id: $product_id})
                    MATCH (u:UserType {type: $user_type})
                    MERGE (p)-[:USE_BY]->(u)
                    """, 
                    parameters={"product_id": product_id, "user_type": user_type_name}
                )

            # Link product to weather conditions (WEATHER_IMPACT)
            for weather_condition in weather_conditions:
                weather_region = weather_condition['region']
                print(f"Creating WEATHER_IMPACT relationship: Product {product_id} -> Weather Condition {weather_region}")
                self._execute_query(
                    """
                    MATCH (p:Product {product_id: $product_id})
                    MATCH (w:WeatherCondition {region: $weather_region})
                    MERGE (p)-[:WEATHER_IMPACT]->(w)
                    """, 
                    parameters={"product_id": product_id, "weather_region": weather_region}
                )

            # Create component relationships (HAS_COMPONENT)
            self._load_product_components_for_product(product_id)


    def _load_data_from_csv(self, csv_file_path):
        data = []
        with open(csv_file_path, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                data.append(row)
        return data

# Neo4j connection details
uri = "bolt://localhost:7691"
user = "admin"
password = "admin1234"

data_loader = Neo4jDataLoader(uri, user, password)

# Load CSV data into Neo4j
data_loader.load_master_category("master_category.csv")
data_loader.load_subcategories("subcategories.csv")
data_loader.load_products("subcategory_products.csv")
data_loader.load_product_components("product_components.csv")
data_loader.load_base_premium("premium.csv")
data_loader.load_years_since_purchase("years_purchase.csv")
data_loader.load_item_conditions("items_condition.csv")
data_loader.load_product_components("product_components.csv")
data_loader.load_user_types("user_types.csv")
data_loader.load_weather_conditions("weather_conditions.csv")

# Create all relationships between products, user types, and weather conditions
data_loader.create_relationships(
    products_csv="subcategory_products.csv",
    user_types_csv="user_types.csv",
    weather_conditions_csv="weather_conditions.csv"
)
data_loader.create_relationships_with_additional_data(
    products_csv="subcategory_products.csv",
    base_premium_csv="premium.csv",
    years_csv="years_purchase.csv",
    conditions_csv="items_condition.csv"
)

data_loader.close()
