import os
import subprocess
import logging
from typing import List, Optional

from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain_community.chat_models import AzureChatOpenAI
from pydantic import BaseModel, Field
from dotenv import load_dotenv


# Load environment variables from .env file
load_dotenv()

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("conversion_report.log"),
        logging.StreamHandler()
    ]
)


# 1. Pydantic Model for Grounding Requirements
class CodeConversionRequest(BaseModel):
    """Defines the structure for a code conversion request."""
    source_code: str = Field(description="The source code to be converted.")
    source_framework: str = Field(default=".NET Framework 4.0", description="The source .NET framework version.")
    target_framework: str = Field(default=".NET Core 8", description="The target .NET framework version.")
    file_path: str = Field(description="The original file path of the code being converted.")

class CodeConversionResponse(BaseModel):
    """Defines the structure for the converted code response."""
    converted_code: str = Field(description="The converted C# code.")
    new_file_path: str = Field(description="The suggested new file path in the .NET Core structure.")
    success: bool = Field(description="Indicates if the conversion was successful.")
    error_message: Optional[str] = Field(default=None, description="Error message if conversion failed.")


# 2. LLM Chain for Code Conversion
def get_conversion_chain() -> LLMChain:
    """Initializes and returns the LLMChain for code conversion."""
    # This prompt engineering is crucial. It needs to be refined for optimal results.
    prompt_template = """
    You are an expert .NET developer specializing in framework migration. Your task is to convert the following C# code from {source_framework} to {target_framework}.

    **Conversion Guidelines:**
    1.  **Modern Patterns:** You MUST use the latest C# and {target_framework} code patterns, including but not limited to:
        *   Dependency Injection (DI) where appropriate (e.g., replacing `HttpContext.Current`).
        *   Async/await for all I/O-bound operations.
        *   Minimal APIs for new endpoints if applicable.
        *   Configuration using `appsettings.json` instead of `Web.config`.
        *   Correct package references for .NET Core (e.g., `Microsoft.AspNetCore.Mvc`).
    2.  **Code Only:** Your response MUST contain ONLY the raw C# code for the converted file. Do NOT include any explanations, markdown formatting (like ```csharp), or any text other than the code itself.
    3.  **File Path:** Based on the original file path (`{file_path}`), determine the appropriate location and filename in a standard .NET Core 8 web application structure.

    **Original File Path:** {file_path}
    **Source Code ({source_framework}):**
    ```csharp
    {source_code}
    ```

    **Converted Code ({target_framework}):**
    """

    # Configure the Azure OpenAI client
    # This uses the environment variables loaded from the .env file
    llm = AzureChatOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
        temperature=0.1,
    )

    prompt = PromptTemplate(
        template=prompt_template,
        input_variables=["source_code", "source_framework", "target_framework", "file_path"]
    )

    return LLMChain(llm=llm, prompt=prompt)


# 3. Validation and Regeneration
def validate_and_regenerate(
    chain: LLMChain,
    request: CodeConversionRequest,
    new_project_path: str,
    max_retries: int = 3
) -> CodeConversionResponse:
    """
    Generates, saves, and validates code. Retries on failure.
    """
    for attempt in range(max_retries):
        try:
            # Get raw response from LLM
            raw_llm_response = chain.run(request.dict())
            
            # This is a simplified assumption. A more robust solution would have the LLM
            # return a JSON object with the code and the new path. For now, we parse it.
            # We check if the first line contains the new path suggestion.
            raw_llm_response = raw_llm_response.strip()
            lines = raw_llm_response.split('\n')
            
            if lines and lines[0].strip().startswith("// New Path:"):
                # LLM provided a path suggestion, parse it.
                new_file_path_suggestion = lines[0].strip()
                suggested_relative_path = new_file_path_suggestion.split('// New Path: ')[1].strip()
                new_file_path = os.path.join(new_project_path, suggested_relative_path)
                converted_code = "\n".join(lines[1:])
            else:
                # Fallback: LLM did not provide a path. Use the original filename.
                # The entire response is treated as code.
                original_filename = os.path.basename(request.file_path)
                new_file_path = os.path.join(new_project_path, original_filename)
                converted_code = raw_llm_response


            # Create directories if they don't exist
            os.makedirs(os.path.dirname(new_file_path), exist_ok=True)

            # Save the converted code
            with open(new_file_path, "w", encoding="utf-8") as f:
                f.write(converted_code)

            # Validate by trying to build the project
            logging.info(f"Attempt {attempt + 1}: Validating {new_file_path}...")
            # We build the whole project. A more granular validation is possible but complex.
            process = subprocess.run(
                ["dotnet", "build", new_project_path],
                capture_output=True,
                text=True,
                check=False # Don't throw exception on non-zero exit code
            )

            if process.returncode == 0:
                logging.info("Validation successful.")
                return CodeConversionResponse(
                    converted_code=converted_code,
                    new_file_path=new_file_path,
                    success=True
                )
            else:
                error_message = f"Build failed:\n{process.stdout}\n{process.stderr}"
                logging.error(error_message)
                # In a real scenario, you might feed this error back into the prompt for the next attempt
                if os.path.exists(new_file_path):
                    os.remove(new_file_path) # Clean up failed file

        except Exception as e:
            logging.error(f"An error occurred during conversion attempt {attempt + 1}: {e}")
            # Clean up if a file was created before an error
            if 'new_file_path' in locals() and os.path.exists(new_file_path):
                os.remove(new_file_path)

    return CodeConversionResponse(
        converted_code="",
        new_file_path="",
        success=False,
        error_message="Max retries reached. Conversion failed."
    )


# 4. Main Orchestration
def convert_project(source_directory: str, target_directory: str):
    """
    Orchestrates the conversion of a .NET Framework project.
    """
    if not os.path.isdir(source_directory):
        logging.error(f"Error: Source directory '{source_directory}' not found.")
        return

    # Create a new .NET Core Web App project structure
    new_project_name = os.path.basename(os.path.normpath(target_directory))
    subprocess.run(["dotnet", "new", "webapp", "-n", new_project_name, "-o", target_directory], check=True)
    logging.info(f"Created new .NET Core 8 project at '{target_directory}'")

    conversion_chain = get_conversion_chain()

    # Walk through the old directory
    for root, _, files in os.walk(source_directory):
        for file in files:
            # Process only C# files for now. Could be extended for .aspx, .config, etc.
            if file.endswith(".cs"):
                file_path = os.path.join(root, file)
                logging.info(f"\n--- Processing: {file_path} ---")
                with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                    source_code = f.read()

                request = CodeConversionRequest(
                    source_code=source_code,
                    file_path=file_path
                )

                result = validate_and_regenerate(
                    chain=conversion_chain,
                    request=request,
                    new_project_path=target_directory
                )

                if result.success:
                    logging.info(f"SUCCESS: Converted '{file_path}' and saved to '{result.new_file_path}'")
                else:
                    logging.error(f"FAILURE: Failed to convert '{file_path}'. Reason: {result.error_message}")
                    # Decide if you want to stop on first failure or continue
                    # return

    logging.info("\n--- Conversion process completed. ---")
    logging.info(f"Final project available at: {target_directory}")
    logging.info("Review 'conversion_report.log' for a detailed summary of the process.")


if __name__ == "__main__":
    # --- CONFIGURATION ---
    # IMPORTANT: Replace with the actual path to your old .NET Framework project
    OLD_PROJECT_DIR = "C:/path/to/your/old/dotnet_framework_app"
    # IMPORTANT: This directory will be CREATED with the new .NET Core project
    NEW_PROJECT_DIR = "./converted_net_core_app"

    logging.info("Starting .NET Code Conversion Process...")
    # Ensure you have the .NET SDK installed and the 'dotnet' command is in your PATH.
    # The script will now load the OPENAI_API_KEY from the .env file.
    
    # A check to prevent running with placeholder paths
    if "C:/path/to/your/old/dotnet_framework_app" in OLD_PROJECT_DIR:
        logging.warning("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        logging.warning("!!! PLEASE UPDATE THE 'OLD_PROJECT_DIR' VARIABLE IN   !!!")
        logging.warning("!!! 'net_converter.py' TO POINT TO YOUR PROJECT.      !!!")
        logging.warning("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    else:
        convert_project(OLD_PROJECT_DIR, NEW_PROJECT_DIR)
