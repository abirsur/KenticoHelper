from agents.address_agent import process_addresses
from agents.email_agent import process_email
from agents.name_agent import process_name
from agents.lob_agent import collect_lobs
from agents.effective_date_agent import process_effective_date
import pprint

extracted_dataset = [ 
    { "DataType": "Accord125", "ExtractedData": { "Client_Name": "David Miller", "Client_Address_Street": "123 Bon St", "Client_Address_City": "London", "Client_Address_Zip": "34553", "Client_Address_State": "", "Client_Address_Country": "UK", "Client_Email": "dmiller@gmail.com", "LOB": "Yacht, Umbrella", "Policy_no": "E987758", "Policy_effective_date": "07/17/2023", "Policy_expiration_date": "07/16/2025", "Broker_Name": "Don Miller", "Broker_Address_Street": "", "Broker_Address_City": "London", "Broker_Address_Zip": "34553", "Broker_Address_State": "", "Broker_Address_Country": "", "Broker_Email": "d.miller@stremmer.com" } }, 
    { "DataType": "Accord152", "ExtractedData": { "Client_Name": "Sarah Johnson", "Client_Address_Street": "176 Brnun Road", "Client_Address_City": "New York", "Client_Address_Zip": "9983", "Client_Address_State": "", "Client_Address_Country": "USA", "Client_Email": "s.johnson@example.com", "LOB": "Auto", "Policy_no": "A123456", "Policy_effective_date": "08/01/2023", "Policy_expiration_date": "07/31/2024", "Broker_Name": "John Doe", "Broker_Address_Street": "456 Elm St", "Broker_Address_City": "New York", "Broker_Address_Zip": "10001", "Broker_Address_State": "NY", "Broker_Address_Country": "USA", "Broker_Email": "john.doe@brokerage.com" } }, 
    { "DataType": "Accord140", "ExtractedData": { "Client_Name": "", "Client_Address_Street": "789 Oak Ave", "Client_Address_City": "Miami", "Client_Address_Zip": "67890", "Client_Address_State": "CA", "Client_Address_Country": "", "Client_Email": "contact@company.com", "LOB": "General Liability", "Policy_no": "G123789", "Policy_effective_date": "07/17/2023", "Policy_expiration_date": "12/31/2024", "Broker_Name": "Jane Smith", "Broker_Address_Street": "789 Oak Ave", "Broker_Address_City": "Los Angeles", "Broker_Address_Zip": "", "Broker_Address_State": "CA", "Broker_Address_Country": "USA", "Broker_Email": "" } }, 
    { "DataType": "Broker", "ExtractedData": { "Client_Name": "Emily White", "Client_Address_Street": "8872 emli st", "Client_Address_City": "venguard", "Client_Address_Zip": "11223", "Client_Address_State": "", "Client_Address_Country": "France", "Client_Email": "emily.white@domain.com", "LOB": "Property", "Policy_no": "P456123", "Policy_effective_date": "09/01/2023", "Policy_expiration_date": "08/31/2024", "Broker_Name": "TYTY Agency", "Broker_Address_Street": "101 Maple St", "Broker_Address_City": "Chicago", "Broker_Address_Zip": "60616", "Broker_Address_State": "IL", "Broker_Address_Country": "USA", "Broker_Email": "m.brown@insurance.com" } }, 
    { "DataType": "Email", "ExtractedData": { "Client_Name": "Emily White", "Client_Address_Street": "8872 emli st", "Client_Address_City": "venguard", "Client_Address_Zip": "11223", "Client_Address_State": "", "Client_Address_Country": "France", "Client_Email": "emily.white@domain.com", "LOB": "", "Policy_no": "", "Policy_effective_date": "", "Policy_expiration_date": "", "Broker_Name": "Sam Wilson", "Broker_Address_Street": "202 Pine St", "Broker_Address_City": "Boston", "Broker_Address_Zip": "02108", "Broker_Address_State": "MA", "Broker_Address_Country": "USA", "Broker_Email": "Aaron.P@yundai.com" } } ]

if __name__ == "__main__":
# Process the dataset
    processed_dataset = []
    addresses = process_addresses(extracted_dataset)
    emails = process_email(extracted_dataset)
    names = process_name(extracted_dataset, emails["Client_Email"], emails["Broker_Email"])
    lobs = collect_lobs(extracted_dataset)
    effective_date_data = process_effective_date(extracted_dataset)

    # Print the processed data for verification
    pprint.pprint(addresses)
    pprint.pprint(emails)
    pprint.pprint(names)
    pprint.pprint(lobs)
    pprint.pprint(effective_date_data)


