from agents.common import fuzzy_match_v1

def extract_effective_dates(extracted_dataset):
    """
    Extract effective dates from the dataset.
    """
    dates = []
    for data in extracted_dataset:
        effective_date = data["ExtractedData"].get("Policy_effective_date", "")
        if effective_date:
            dates.append({
                "date": effective_date,
                "data_type": data["DataType"]
            })
    
    return dates

def process_effective_date(extracted_dataset):
    """
    Determine the best effective date based on the email data or by fuzzy matching.
    """
    # First, check if effective date is present in the Email model
    email_dates = [data["ExtractedData"].get("Policy_effective_date", "") for data in extracted_dataset if data["DataType"] == "Email"]
    
    if email_dates and email_dates[0] != '':
        return {
            "Effective_Date": email_dates[0]  # Assuming there's only one effective date in the Email model
        }
    
    # If not found in Email, perform fuzzy matching on all effective dates in the dataset
    all_dates = extract_effective_dates(extracted_dataset)
    date_matches = fuzzy_match_v1(all_dates, 'date')
    
    # Select the best date based on the highest score
    best_match = max(date_matches, key=lambda x: x["score"], default={"source": ""})
    
    return {
        "Effective_Date": best_match["source"]["date"]
    }