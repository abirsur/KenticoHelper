def collect_lobs(extracted_dataset):
    """
    Collect all Lines of Business (LOBs) from the dataset and join them into a comma-separated string.
    """
    lob_set = set() 
    for data in extracted_dataset:
        lob = data["ExtractedData"].get("LOB", "")
        if lob:
            lob_entries = [entry.strip() for entry in lob.split(',') if entry.strip()]
            lob_set.update(lob_entries)
    lob_string = ', '.join(sorted(lob_set))
    return {'LOB': lob_string }
