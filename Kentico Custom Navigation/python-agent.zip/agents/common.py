import faiss
import numpy as np
from difflib import SequenceMatcher

# Function to compute similarity score between two strings
def compute_similarity_score(a, b):
    """
    Compute a similarity score between two strings using SequenceMatcher.
    This will return a ratio between 0 and 1, where 1 is a perfect match.
    """
    return SequenceMatcher(None, a, b).ratio()

# Function to perform fuzzy matching using FAISS
def fuzzy_match_v1(data_list, key_field):
    """
    Perform fuzzy matching on the list of data (addresses/emails) using FAISS and string similarity.
    Returns the best match based on the criteria provided, including data type.
    """
    num_entries = len(data_list)
    similarity_matrix = np.zeros((num_entries, num_entries), dtype=np.float32)
    
    for i in range(num_entries):
        for j in range(num_entries):
            if i != j:
                similarity_matrix[i, j] = compute_similarity_score(data_list[i][key_field], data_list[j][key_field])
    
    # Convert similarity scores to negative distances for FAISS
    distances = 1.0 - similarity_matrix
    
    # Create a FAISS index
    index = faiss.IndexFlatL2(num_entries)
    index.add(distances)
    
    # Perform a search for each entry in the dataset
    matches = []
    for i in range(num_entries):
        D, I = index.search(np.expand_dims(distances[i], axis=0), num_entries)
        
        source_entry = data_list[i]
        target_entry = data_list[I[0][1]]  # The best match is the second closest, after itself
        score = 1 - D[0][1]  # Convert back to similarity score
        
        match_type = "Worst or No Match"
        if score > 0.9:  # Full match
            match_type = "Best Match"
        elif score > 0.5:  # Partial match
            match_type = "Partial Match"
        
        matches.append({
            "source": source_entry,
            "target": target_entry,
            "score": score,
            "match_type": match_type,
            "data_type": source_entry['data_type']
        })
    
    return matches

def fuzzy_match_names(name_list, email_name):
    """
    Perform fuzzy matching between the extracted name from email and names in the list.
    Returns the best match based on the criteria provided.
    """
    best_score = 0
    best_name = email_name

    for name in name_list:
        score = SequenceMatcher(None, email_name, name).ratio()
        if score > best_score:
            best_score = score
            best_name = name

    match_quality = (
        "best" if best_score > 0.8 
        else "partial" if best_score > 0.4 
        else "poor"
    )

    return {
        "best_name": best_name,
        "score": match_quality
    }
