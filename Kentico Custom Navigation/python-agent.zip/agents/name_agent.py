import re
from difflib import SequenceMatcher
from agents.common import fuzzy_match_names

def extract_name_from_email(email):
    """
    Extract name from the email address.
    Assumes that the email is in the format 'name@example.com'.
    """
    match = re.match(r'([^@]+)', email)
    if match:
        return match.group(1).replace('.', ' ').title()
    return ""


def Client_Name_Agent(client_names, client_emails):
    """
    Determine the best client name based on names from data models and email.
    """
    for email, _ in client_emails:
        extracted_name = extract_name_from_email(email)
        match = fuzzy_match_names(client_names, extracted_name)

        if match['score'] == 'best':
            return match['best_name']
    
    # If no good match found, fallback to the name extracted from the email
    return extracted_name

def Broker_Name_Agent(broker_names, broker_emails):
    """
    Determine the best broker name based on names from data models and email.
    """
    for email, _ in broker_emails:
        extracted_name = extract_name_from_email(email)
        match = fuzzy_match_names(broker_names, extracted_name)

        if match['score'] == 'best':
            return match['best_name']
    
    # If no good match found, fallback to the name extracted from the email
    return extracted_name

def process_name(extracted_dataset, client_email, broker_email):
    """
    Process the names by integrating the Client_Name_Agent and Broker_Name_Agent.
    Returns a merged model with client and broker names.
    """
    # Collect client names and emails
    client_names = [data["ExtractedData"].get("Client_Name", "") for data in extracted_dataset]
    client_emails = [(data["ExtractedData"].get("Client_Email", ""), data["DataType"]) for data in extracted_dataset if "Client_Email" in data["ExtractedData"]]
    
    # Collect broker names and emails
    broker_names = [data["ExtractedData"].get("Broker_Name", "") for data in extracted_dataset]
    broker_emails = [(data["ExtractedData"].get("Broker_Email", ""), data["DataType"]) for data in extracted_dataset if "Broker_Email" in data["ExtractedData"]]

    # Determine best client and broker names
    client_name = Client_Name_Agent(client_names, [(client_email, "Email")])
    broker_name = Broker_Name_Agent(broker_names, [(broker_email, "Email")])

    return {
        "Client_Name": client_name,
        "Broker_Name": broker_name
    }