from agents.common import fuzzy_match_v1

# Function to identify address fields based on a given prefix
def identify_address_fields(data_entry, prefix):
    """
    Identify address fields based on a given prefix.
    """
    return {
        "Street": data_entry.get(f"{prefix}_Street", ""),
        "City": data_entry.get(f"{prefix}_City", ""),
        "Zip": data_entry.get(f"{prefix}_Zip", ""),
        "State": data_entry.get(f"{prefix}_State", ""),
        "Country": data_entry.get(f"{prefix}_Country", ""),
    }

# Function to combine street, city, zip, state, and country into a full address string
def combine_address_fields(address_data):
    """
    Combine street, city, zip, state, and country into a full address string.
    """
    return ', '.join(filter(None, [
        address_data.get('Street', ''),
        address_data.get('City', ''),
        address_data.get('Zip', ''),
        address_data.get('State', ''),
        address_data.get('Country', '')
    ])).strip()

# Function to split a full address string into its components
def split_address(full_address):
    """
    Split a full address string into its components: street, city, zip, state, country.
    """
    components = full_address.split(', ')
    return {
        "Street": components[0] if len(components) > 0 else "",
        "City": components[1] if len(components) > 1 else "",
        "Zip": components[2] if len(components) > 2 else "",
        "State": components[3] if len(components) > 3 else "",
        "Country": components[4] if len(components) > 4 else "",
    }

# Function for client address agent
def Client_Address_Agent(data):
    """
    Process client addresses from the given data and return a single model with the best address.
    """
    address_list = []
    
    for entry in data:
        client_name = entry['ExtractedData'].get('Client_Name', '')
        client_address = {
            'Street': entry['ExtractedData'].get('Client_Address_Street', ''),
            'City': entry['ExtractedData'].get('Client_Address_City', ''),
            'Zip': entry['ExtractedData'].get('Client_Address_Zip', ''),
            'State': entry['ExtractedData'].get('Client_Address_State', ''),
            'Country': entry['ExtractedData'].get('Client_Address_Country', '')
        }
        
        # Combine address fields into a full address
        full_address = combine_address_fields(client_address)
        
        address_list.append({
            'full_address': full_address,
            'data_type': entry['DataType'],
            'original_entry': entry,
            'name': client_name
        })

    matches = fuzzy_match_v1(address_list, key_field='full_address')
    
    best_address = None
    best_match_score = -1
    best_address_entry = None

    # Determine the best match
    for match in matches:
        source_entry = match['source']['original_entry']
        target_entry = match['target']['original_entry']
        match_type = match['match_type']
        score = match['score']
        
        if match_type == "Best Match":
            best_address = combine_address_fields(identify_address_fields(target_entry['ExtractedData'], 'Client_Address'))
            best_match_score = score
            best_address_entry = target_entry
            break
        elif match_type == "Partial Match":
            if score > best_match_score:
                best_address = combine_address_fields(identify_address_fields(target_entry['ExtractedData'], 'Client_Address'))
                best_match_score = score
                best_address_entry = target_entry
            elif score == best_match_score:
                source_length = len(match['source']['full_address'])
                target_length = len(match['target']['full_address'])
                if target_length > source_length:
                    best_address = combine_address_fields(identify_address_fields(target_entry['ExtractedData'], 'Client_Address'))
                    best_address_entry = target_entry
        else:
            if address_list:
                larger_address = max([e['full_address'] for e in address_list if e['full_address']], key=len, default='')
                best_address = larger_address
    
    # Call LLM to fill missing state and country if necessary
    client_address = split_address(best_address) if best_address else {}
    if not client_address.get('State') or not client_address.get('Country'):
        # Placeholder for LLM call
        # client_address = call_llm_to_fill_missing_data(client_address)
        pass
    
    # Create the final model
    client_model = {
        "DataType": best_address_entry['DataType'] if best_address_entry else "Final",
        "ExtractedData": {
            "Client_Name": best_address_entry['ExtractedData'].get('Client_Name', '') if best_address_entry else "",
            "Client_Address_Street": client_address.get("Street", ""),
            "Client_Address_City": client_address.get("City", ""),
            "Client_Address_Zip": client_address.get("Zip", ""),
            "Client_Address_State": client_address.get("State", ""),
            "Client_Address_Country": client_address.get("Country", ""),
            "Client_Email": ""  # Blank as per requirement
        }
    }

    return client_model

# Function for broker address agent
def Broker_Address_Agent(data):
    """
    Process broker addresses from the given data and return a single model with the best address.
    """
    address_list = []
    email_address = None
    
    for entry in data:
        broker_name = entry['ExtractedData'].get('Broker_Name', '')
        broker_address = {
            'Street': entry['ExtractedData'].get('Broker_Address_Street', ''),
            'City': entry['ExtractedData'].get('Broker_Address_City', ''),
            'Zip': entry['ExtractedData'].get('Broker_Address_Zip', ''),
            'State': entry['ExtractedData'].get('Broker_Address_State', ''),
            'Country': entry['ExtractedData'].get('Broker_Address_Country', '')
        }
        
        # Combine address fields into a full address
        full_address = combine_address_fields(broker_address)
        
        address_list.append({
            'full_address': full_address,
            'data_type': entry['DataType'],
            'original_entry': entry,
            'name': broker_name
        })
        
        # Collect email address if present
        if entry['DataType'].lower() == 'email':
            email_address = {
                'Street': entry['ExtractedData'].get('Broker_Address_Street', ''),
                'City': entry['ExtractedData'].get('Broker_Address_City', ''),
                'Zip': entry['ExtractedData'].get('Broker_Address_Zip', ''),
                'State': entry['ExtractedData'].get('Broker_Address_State', ''),
                'Country': entry['ExtractedData'].get('Broker_Address_Country', '')
            }
    
    matches = fuzzy_match_v1(address_list, key_field='full_address')
    
    best_address = None
    best_match_score = -1
    best_address_entry = None

    # Determine the best match
    for match in matches:
        source_entry = match['source']['original_entry']
        target_entry = match['target']['original_entry']
        match_type = match['match_type']
        score = match['score']
        
        if match_type == "Best Match":
            best_address = combine_address_fields(identify_address_fields(target_entry['ExtractedData'], 'Broker_Address'))
            best_match_score = score
            best_address_entry = target_entry
            break
        elif match_type == "Partial Match":
            if score > best_match_score:
                best_address = combine_address_fields(identify_address_fields(target_entry['ExtractedData'], 'Broker_Address'))
                best_match_score = score
                best_address_entry = target_entry
            elif score == best_match_score:
                source_length = len(match['source']['full_address'])
                target_length = len(match['target']['full_address'])
                if target_length > source_length:
                    best_address = combine_address_fields(identify_address_fields(target_entry['ExtractedData'], 'Broker_Address'))
                    best_address_entry = target_entry
        else:
            if address_list:
                larger_address = max([e['full_address'] for e in address_list if e['full_address']], key=len, default='')
                best_address = larger_address
    
    # If no best address found, use email address if available
    if not best_address:
        if email_address:
            best_address = combine_address_fields(email_address)
        else:
            # Choose the larger address string among all available addresses
            if address_list:
                larger_address = max([e['full_address'] for e in address_list if e['full_address']], key=len, default='')
                best_address = larger_address
    
    # Call LLM to fill missing state and country if necessary
    broker_address = split_address(best_address) if best_address else {}
    if not broker_address.get('State') or not broker_address.get('Country'):
        # Placeholder for LLM call
        # broker_address = call_llm_to_fill_missing_data(broker_address)
        pass
    
    # Create the final model
    broker_model = {
        "DataType": best_address_entry['DataType'] if best_address_entry else "Final",
        "ExtractedData": {
            "Broker_Name": best_address_entry['ExtractedData'].get('Broker_Name', '') if best_address_entry else "",
            "Broker_Address_Street": broker_address.get("Street", ""),
            "Broker_Address_City": broker_address.get("City", ""),
            "Broker_Address_Zip": broker_address.get("Zip", ""),
            "Broker_Address_State": broker_address.get("State", ""),
            "Broker_Address_Country": broker_address.get("Country", ""),
            "Broker_Email": ""  # Blank as per requirement
        }
    }

    return broker_model

def process_addresses(data):
    """
    Process the provided data to identify client and broker addresses, 
    and return a merged model containing only client and broker addresses.
    """
    # Separate client and broker data based on property keys
    client_data = []
    broker_data = []
    merged_model = []
    for entry in data:
        extracted_data = entry['ExtractedData']
        # Identify if the entry is for client or broker
        for key in extracted_data.keys():
            if 'client_' in key.lower():
                client_data.append(entry)
                
            if 'broker_' in key.lower():
                broker_data.append(entry)
                
    
    # Process client and broker data separately
    client_model = Client_Address_Agent(client_data)
    merged_model.append(client_model)
    broker_model = Broker_Address_Agent(broker_data)
    merged_model.append(broker_model)
    
    # Merge the two models
    return merged_model
