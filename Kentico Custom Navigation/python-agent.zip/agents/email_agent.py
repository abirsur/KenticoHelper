import numpy as np
import faiss
from difflib import SequenceMatcher
from agents.common import fuzzy_match_v1

def select_larger_or_email(data_list):
    # Prioritize data from "Email" DataType or select the larger one
    for email, datatype in data_list:
        if datatype == "Email":
            return email
    return max(data_list, key=lambda x: len(x[0]))[0]  # Choose by larger string

def select_best_email(email_matches, email_data):
    """
    Select the best email based on match score and availability.
    """
    best_match = max(email_matches, key=lambda x: x['score'], default=None)
    
    if best_match and best_match['score'] == 1:
        return best_match['source']
    
    if email_data:
        return email_data
    
    return max(email_matches, key=lambda x: x['score'], default={'source': ''})['source']

def Client_Email_Agent(extracted_dataset):
    # Collect all client emails
    client_emails = []
    for data in extracted_dataset:
        for key, value in data["ExtractedData"].items():
            if "client_email" in key.lower():
                client_emails.append({"email_address": value, "data_type": data["DataType"]})
    
    # Perform fuzzy match
    matches = fuzzy_match_v1(client_emails, key_field='email_address')

    # Determine the best client email
    best_match = max(matches, key=lambda x: x['score'], default=None)
    if best_match and best_match['match_type'] == 'Best Match':
        selected_email = best_match['source']['email_address']
    else:
        selected_email = select_larger_or_email([(entry['email_address'], entry['data_type']) for entry in client_emails])

    return {
        "Client_Email": selected_email,
        "DataType": best_match['source']['data_type'] if best_match else ""
    }

def Broker_Email_Agent(extracted_dataset):
    # Collect all broker emails
    broker_emails = []
    for data in extracted_dataset:
        for key, value in data["ExtractedData"].items():
            if "broker_email" in key.lower():
                broker_emails.append({"email_address": value, "data_type": data["DataType"]})

    # Perform fuzzy match
    matches = fuzzy_match_v1(broker_emails, key_field='email_address')

    # Determine the best broker email
    best_match = max(matches, key=lambda x: x['score'], default=None)
    if best_match and best_match['match_type'] == 'Best Match':
        selected_email = best_match['source']['email_address']
    else:
        selected_email = select_larger_or_email([(entry['email_address'], entry['data_type']) for entry in broker_emails])

    return {
        "Broker_Email": selected_email,
        "DataType": best_match['source']['data_type'] if best_match else ""
    }

def process_email(extracted_dataset):
    client_email_data = Client_Email_Agent(extracted_dataset)
    broker_email_data = Broker_Email_Agent(extracted_dataset)

    # Check if client email and broker email are not the same
    if client_email_data["Client_Email"] != broker_email_data["Broker_Email"]:
        return {
            "Client_Email": client_email_data["Client_Email"],
            "Broker_Email": broker_email_data["Broker_Email"]
        }
    else:
        # Handle the case where the emails are the same (e.g., raise an error, return a specific value, etc.)
        raise ValueError("Client email and Broker email should not be the same.")
