import logging
from fastapi.responses import JSONResponse

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Exception handling
async def global_exception_handler(request, exc):
    logger.error(f"Exception: {exc}")
    return JSONResponse(status_code=500, content={"message": str(exc)})