from fastapi import APIRouter, BackgroundTasks, UploadFile, File
from .models import ParseRequest
from .controllers.data_extraction_controller import DataExtractionController
import logging

logger = logging.getLogger(__name__)

router = APIRouter()

@router.post("/parse")
async def parse_document(file: UploadFile = File(...), schema: str = "", config: str = "", background_tasks: BackgroundTasks):
    logger.info(f"Received request: {file.filename}")
    background_tasks.add_task(process_request, file, schema, config)
    return {"message": "Request is being processed"}

def process_request(file: UploadFile, schema: str, config: str):
    try:
        controller = DataExtractionController.get_instance()
        result = controller.handle_request(file, schema, config)
        logger.info(f"Final result: {result}")
    except Exception as e:
        logger.error(f"Error processing request: {e}")
        raise