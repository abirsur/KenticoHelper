from pydantic import BaseModel

class ParseRequest(BaseModel):
    file_type: str
    content: str