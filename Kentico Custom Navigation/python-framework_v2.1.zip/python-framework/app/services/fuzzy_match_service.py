from ..utils import logger

class FuzzyMatchService:
    _instance = None

    @staticmethod
    def get_instance():
        if FuzzyMatchService._instance is None:
            FuzzyMatchService._instance = FuzzyMatchService()
        return FuzzyMatchService._instance

    def get_better_synonyms(self, text: str, **kwargs):
        try:
            logger.info("Getting better synonyms using fuzzy matching")
            # Implement fuzzy matching logic here
            return "better synonym"  # Modify as needed based on text and kwargs
        except Exception as e:
            logger.error(f"Error in FuzzyMatchService: {e}")
            raise