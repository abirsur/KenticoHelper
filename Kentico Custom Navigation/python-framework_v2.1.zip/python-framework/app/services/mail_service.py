from ..utils import logger
import email
from email import policy
from email.parser import BytesParser

class MailService:
    _instance = None

    @staticmethod
    def get_instance():
        if MailService._instance is None:
            MailService._instance = MailService()
        return MailService._instance

    def __init__(self):
        if MailService._instance is not None:
            raise Exception("This class is a singleton!")

    def parse_mail(self, file, **kwargs):
        try:
            logger.info("Parsing mail")
            msg = BytesParser(policy=policy.default).parsebytes(file.file.read())
            mail_content = msg.get_body(preferencelist=('plain')).get_content()
            attachments = []
            for part in msg.iter_attachments():
                attachment = {
                    "file_type": part.get_content_type(),
                    "content": part.get_payload(decode=True)
                }
                attachments.append(attachment)
            return mail_content, attachments
        except Exception as e:
            logger.error(f"Error in MailService: {e}")
            raise