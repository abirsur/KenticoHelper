from ..utils import logger

class GPTService:
    _instance = None

    @staticmethod
    def get_instance():
        if GPTService._instance is None:
            GPTService._instance = GPTService()
        return GPTService._instance

    def extract_data(self, parsed_data, schema: str, **kwargs):
        try:
            logger.info("Extracting data using GPT")
            # Implement GPT extraction logic here
            return {"gpt_extracted": "data"}  # Modify as needed based on schema and kwargs
        except Exception as e:
            logger.error(f"Error in GPTService: {e}")
            raise