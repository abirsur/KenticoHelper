from ..utils import logger

class DocumentParserFactory:
    @staticmethod
    def get_parser(file_type: str):
        if file_type == "mail":
            from .mail_parser import MailParser
            return MailParser()
        elif file_type == "document":
            from .document_parser import DocumentParser
            return DocumentParser()
        elif file_type == "pdf":
            from .pdf_parser import PDFParser
            return PDFParser()
        else:
            raise ValueError("Unsupported file type")

class BaseParser:
    def parse(self, content: str, **kwargs):
        raise NotImplementedError("Parse method not implemented")