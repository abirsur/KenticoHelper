from .base_parser import BaseParser
from ..utils import logger
from ..services.gpt_vision_service import GPTVisionService
from ..services.fuzzy_match_service import FuzzyMatchService

class PDFParser(BaseParser):
    def __init__(self):
        self.gpt_vision_service = GPTVisionService.get_instance()
        self.fuzzy_match_service = FuzzyMatchService.get_instance()

    def parse(self, content: str, **kwargs):
        try:
            logger.info("Parsing PDF content")
            # Implement PDF parsing logic here to extract images
            images = self.extract_images_from_pdf(content, **kwargs)
            logger.info(f"Extracted images: {images}")

            # Call GPT Vision for image extraction
            extracted_texts = []
            for image in images:
                extracted_text = self.gpt_vision_service.extract_text_from_image(image, **kwargs)
                logger.info(f"Extracted text from image: {extracted_text}")
                extracted_texts.append(extracted_text)

            # Perform fuzzy matching for better synonyms
            matched_texts = []
            for text in extracted_texts:
                matched_text = self.fuzzy_match_service.get_better_synonyms(text, **kwargs)
                logger.info(f"Matched text: {matched_text}")
                matched_texts.append(matched_text)

            return {"parsed": matched_texts}
        except Exception as e:
            logger.error(f"Error in PDFParser: {e}")
            raise

    def extract_images_from_pdf(self, content: str, **kwargs):
        # Implement logic to extract images from PDF content
        return ["image1", "image2"]