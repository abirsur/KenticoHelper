from fastapi import FastAPI
from .utils import global_exception_handler
from .main import router

app = FastAPI()

# Register exception handler
app.add_exception_handler(Exception, global_exception_handler)

# Include router
app.include_router(router)