import unittest
from app.services.fuzzy_match_service import FuzzyMatchService

class TestFuzzyMatchService(unittest.TestCase):
    def test_get_better_synonyms(self):
        service = FuzzyMatchService.get_instance()
        text = "text"

        result = service.get_better_synonyms(text)

        self.assertEqual(result, "better synonym")

if __name__ == '__main__':
    unittest.main()