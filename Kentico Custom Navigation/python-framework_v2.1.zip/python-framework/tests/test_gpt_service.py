import unittest
from app.services.gpt_service import GPTService

class TestGPTService(unittest.TestCase):
    def test_extract_data(self):
        service = GPTService.get_instance()
        parsed_data = {"key": "value"}
        schema = "schema"

        result = service.extract_data(parsed_data, schema)

        self.assertEqual(result, {"gpt_extracted": "data"})

if __name__ == '__main__':
    unittest.main()