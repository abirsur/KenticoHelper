import unittest
from unittest.mock import patch, MagicMock
from app.controllers.data_extraction_controller import DataExtractionController
from fastapi import UploadFile

class TestDataExtractionController(unittest.TestCase):
    @patch('app.controllers.data_extraction_controller.MailService')
    @patch('app.controllers.data_extraction_controller.GPTService')
    @patch('app.controllers.data_extraction_controller.PostProcessingService')
    @patch('app.controllers.data_extraction_controller.FuzzyMatchService')
    def test_handle_request(self, mock_fuzzy_match_service, mock_post_processing_service, mock_gpt_service, mock_mail_service):
        mock_mail_service.get_instance.return_value.parse_mail.return_value = ("mail_content", [{"file_type": "pdf", "content": "pdf_content"}])
        mock_fuzzy_match_service.get_instance.return_value.get_better_synonyms.return_value = "matched_data"
        mock_gpt_service.get_instance.return_value.extract_data.return_value = "gpt_data"
        mock_post_processing_service.get_instance.return_value.process_data.return_value = "final_data"

        controller = DataExtractionController.get_instance()
        file = MagicMock(spec=UploadFile)
        schema = "schema"
        config = "config"

        result = controller.handle_request(file, schema, config)

        self.assertEqual(result, "final_data")

if __name__ == '__main__':
    unittest.main()