import unittest
from unittest.mock import patch
from app.services.post_processing_service import PostProcessingService

class TestPostProcessingService(unittest.TestCase):
    @patch('app.services.post_processing_service.PostProcessingHelpers')
    @patch('app.services.post_processing_service.FuzzyMatchService')
    @patch('app.services.post_processing_service.GPTService')
    def test_process_data(self, mock_gpt_service, mock_fuzzy_match_service, mock_post_processing_helpers):
        mock_post_processing_helpers.process.return_value = "processed_data"
        mock_fuzzy_match_service.get_instance.return_value.get_better_synonyms.return_value = "matched_data"
        mock_gpt_service.get_instance.return_value.extract_data.return_value = "final_data"

        service = PostProcessingService.get_instance()
        gpt_data = "gpt_data"
        config = "config"

        result = service.process_data(gpt_data, config)

        self.assertEqual(result, "final_data")

if __name__ == '__main__':
    unittest.main()