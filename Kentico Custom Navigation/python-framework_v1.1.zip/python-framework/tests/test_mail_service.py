import unittest
from unittest.mock import MagicMock
from app.services.mail_service import MailService
from fastapi import UploadFile

class TestMailService(unittest.TestCase):
    def test_parse_mail(self):
        service = MailService.get_instance()
        file = MagicMock(spec=UploadFile)
        file.file.read.return_value = b"raw_email_content"

        mail_content, attachments = service.parse_mail(file)

        self.assertEqual(mail_content, "parsed mail content")
        self.assertEqual(attachments, [{"file_type": "application/pdf", "content": b"attachment_content"}])

if __name__ == '__main__':
    unittest.main()