from ..parsers.base_parser import DocumentParserFactory
from ..services.gpt_service import GPTService
from ..services.post_processing_service import PostProcessingService
from ..services.mail_service import MailService
from ..services.fuzzy_match_service import FuzzyMatchService
from ..models import ParseRequest
from ..utils import logger

class DataExtractionController:
    _instance = None

    @staticmethod
    def get_instance():
        if DataExtractionController._instance is None:
            DataExtractionController._instance = DataExtractionController()
        return DataExtractionController._instance

    def __init__(self):
        if DataExtractionController._instance is not None:
            raise Exception("This class is a singleton!")
        self.gpt_service = GPTService.get_instance()
        self.post_processing_service = PostProcessingService.get_instance()
        self.mail_service = MailService.get_instance()
        self.fuzzy_match_service = FuzzyMatchService.get_instance()

    def handle_request(self, file, schema: str, config: str):
        try:
            logger.info("Handling request in DataExtractionController")
            mail_content, attachments = self.mail_service.parse_mail(file)
            logger.info(f"Parsed mail content: {mail_content}")
            logger.info(f"Extracted attachments: {attachments}")

            results = []
            for attachment in attachments:
                parser = DocumentParserFactory.get_parser(attachment["file_type"])
                parsed_data = parser.parse(attachment["content"])
                logger.info(f"Parsed data: {parsed_data}")

                # Perform fuzzy matching before GPT extraction
                matched_data = self.fuzzy_match_service.get_better_synonyms(parsed_data)
                logger.info(f"Matched data: {matched_data}")

                gpt_data = self.gpt_service.extract_data(matched_data, schema)
                logger.info(f"GPT extracted data: {gpt_data}")

                results.append(gpt_data)

            final_data = self.post_processing_service.process_data(results, config)
            logger.info(f"Post-processed data: {final_data}")

            return final_data
        except Exception as e:
            logger.error(f"Error in DataExtractionController: {e}")
            raise