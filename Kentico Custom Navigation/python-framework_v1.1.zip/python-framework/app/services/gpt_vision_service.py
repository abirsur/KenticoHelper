from ..utils import logger

class GPTVisionService:
    _instance = None

    @staticmethod
    def get_instance():
        if GPTVisionService._instance is None:
            GPTVisionService._instance = GPTVisionService()
        return GPTVisionService._instance

    def __init__(self):
        if GPTVisionService._instance is not None:
            raise Exception("This class is a singleton!")

    def extract_text_from_image(self, image):
        try:
            logger.info("Extracting text from image using GPT Vision")
            # Implement GPT Vision extraction logic here
            return "extracted text from image"
        except Exception as e:
            logger.error(f"Error in GPTVisionService: {e}")
            raise