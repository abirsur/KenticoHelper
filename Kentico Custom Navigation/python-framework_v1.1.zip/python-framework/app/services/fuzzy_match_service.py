from ..utils import logger

class FuzzyMatchService:
    _instance = None

    @staticmethod
    def get_instance():
        if FuzzyMatchService._instance is None:
            FuzzyMatchService._instance = FuzzyMatchService()
        return FuzzyMatchService._instance

    def __init__(self):
        if FuzzyMatchService._instance is not None:
            raise Exception("This class is a singleton!")

    def get_better_synonyms(self, text):
        try:
            logger.info("Performing fuzzy matching to get better synonyms")
            # Implement fuzzy matching logic here using text-embedding models
            return "better synonym"
        except Exception as e:
            logger.error(f"Error in FuzzyMatchService: {e}")
            raise