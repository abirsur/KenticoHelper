from ..utils import logger
from ..helpers.post_processing_helpers import PostProcessingHelpers
from ..services.fuzzy_match_service import FuzzyMatchService
from ..services.gpt_service import GPTService

class PostProcessingService:
    _instance = None

    @staticmethod
    def get_instance():
        if PostProcessingService._instance is None:
            PostProcessingService._instance = PostProcessingService()
        return PostProcessingService._instance

    def __init__(self):
        if PostProcessingService._instance is not None:
            raise Exception("This class is a singleton!")
        self.fuzzy_match_service = FuzzyMatchService.get_instance()
        self.gpt_service = GPTService.get_instance()

    def process_data(self, gpt_data, config: str):
        try:
            logger.info("Post-processing data")
            # Implement post-processing logic here
            processed_data = PostProcessingHelpers.process(gpt_data, config)

            # Perform fuzzy matching during post-processing
            matched_data = self.fuzzy_match_service.get_better_synonyms(processed_data)
            logger.info(f"Matched data during post-processing: {matched_data}")

            # Perform additional GPT-based extraction during post-processing
            final_data = self.gpt_service.extract_data(matched_data, config)
            logger.info(f"Final GPT extracted data during post-processing: {final_data}")

            return final_data
        except Exception as e:
            logger.error(f"Error in PostProcessingService: {e}")
            raise